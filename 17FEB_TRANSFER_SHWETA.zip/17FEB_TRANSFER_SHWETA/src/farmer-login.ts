import {Component} from '@angular/core'

export class FarmerLogin{

    constructor(
        public email?:string,
        public password?:string,
        
         ){

         }
}