import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { BidderComponent } from 'src/bidder-component';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BidderService } from 'src/bidder-service';
import { BidderLoginComponent } from 'src/bidder-login-component';
import { BidderLoginService } from 'src/bidder-login-service';
import { FarmerService } from 'FarmerService';
import { FarmerComponent } from 'FarmerComponent';
import { FarmerLoginComponent } from 'src/farmer-login-component';
import { FarmerLoginService } from 'src/farmer-login-service';
 import {RouterModule} from '@angular/router';
import { HomeComponent } from 'src/home-component';

import { BidderDashboardService } from 'src/app/bidder-dashboard-service';
import { BidderDashboardComponent } from 'src/app/bidder-dashboard-component';
import { FarmerDashboard } from './farmerDashboard.component';


@NgModule({
  declarations: [
    AppComponent,
    BidderComponent,
    BidderLoginComponent,
    FarmerComponent,
    FarmerLoginComponent,
    HomeComponent,
    BidderDashboardComponent,
    FarmerDashboard,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
     RouterModule.forRoot( [ 
       { path: 'home', component: HomeComponent},
       { path: 'farmerlogin', component: FarmerLoginComponent},
       { path: 'login', component: BidderLoginComponent},
       { path: 'add-bidder', component: BidderComponent},
       { path: 'add-farmer', component: FarmerComponent},
       { path: 'farmerdashboard', component: FarmerDashboard},



    ])
  ],
  providers: [BidderService,BidderLoginService,HttpClient,FarmerService,FarmerLoginService,BidderDashboardService],
  bootstrap: [AppComponent]
})
export class AppModule { }