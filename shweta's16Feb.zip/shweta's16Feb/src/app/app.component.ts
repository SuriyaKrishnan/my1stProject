import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  //templateUrl: './app.component.html',
  template:`
  <style>
  ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }
  
  li {
    float: left;
  }
  
  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  
  /* Change the link color to #111 (black) on hover */
  li a:hover {
    background-color: red;
  }
  h1 {
    width: 200px;
    
    height: 100px;
    
    background: url('logo.png');
    
    text-indent: -9999px;
    
    }
    .bg {
      /* The image used */
      background-image: url("");
    
      /* Full height */
      height: 100%; 
    
      /* Center and scale the image nicely */
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
    }
    body {
      font-family: Arial, Helvetica, sans-serif;
    }
    
    .navbar {
      overflow: hidden;
      background-color: #333;
    }
    
    .navbar a {
      float: left;
      font-size: 16px;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }
    
    .dropdown {
      float: left;
      overflow: hidden;
    }
    
    .dropdown .dropbtn {
      font-size: 16px;  
      border: none;
      outline: none;
      color: white;
      padding: 14px 16px;
      background-color: inherit;
      font-family: inherit;
      margin: 0;
    }
    
    .navbar a:hover, .dropdown:hover .dropbtn {
      background-color: red;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #f9f9f9;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      z-index: 1;
    }
    
    .dropdown-content a {
      float: none;
      color: black;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
      text-align: left;
    }
    
    .dropdown-content a:hover {
      background-color: #ddd;
    }
    
    .dropdown:hover .dropdown-content {
      display: block;
    }
  </style>
  <body>
 <div>
  <ul class="nav navbar-nav">
  <li><a [routerLink]="['/home']">HOME</a></li>
  <li><a [routerLink]="['/about']">ABOUT US</a></li>
  <li><a [routerLink]="['/contact-us']">CONTACT US</a></li>

  <div class="navbar">
  <div class="dropdown">
    <button class="dropbtn">LOGIN 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a [routerLink]="['/farmerlogin']">FARMER LOGIN</a>
      <a [routerLink]="['/login']">BIDDER LOGIN</a>
</div>

</div>

<div class="navbar">
<div class="dropdown">
  <button class="dropbtn">REGISTRATION 
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-content">
<a [routerLink]="['/add-farmer']">FARMER REGISTRATION</a>
<a [routerLink]="['/add-bidder']">BIDDER REGISTRATION</a>
</div></div></div>

</div>

  </ul>
  
 </div>
  
  </body>
 
 
  <div class="bg"></div>
  <div class='container'>
  <router-outlet></router-outlet>
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular';
}



