import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from 'src/home-component';
import { FarmerLoginComponent } from 'src/farmer-login-component';
import { BidderLoginComponent } from 'src/bidder-login-component';
import { BidderComponent } from 'src/bidder-component';
import { FarmerComponent } from 'FarmerComponent';
import { FarmerDashboard } from './farmerDashboard.component';

const routes: Routes = [

    { path: 'home', component: HomeComponent},
    { path: 'farmerlogin', component: FarmerLoginComponent},
    { path: 'login', component: BidderLoginComponent},
    { path: 'add-bidder', component: BidderComponent},
    { path: 'add-farmer', component: FarmerComponent},
    { path: 'farmerdashboard', component: FarmerDashboard}


 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routing = RouterModule.forRoot(routes);
