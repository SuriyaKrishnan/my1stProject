import {Component} from '@angular/core'

export class BidderDashboard {

    constructor(
       
        public cropType?:string,
        public cropName?:string,
        public priceperquintal?:string,
        public currentBid?:number,
    ){

    }
}
