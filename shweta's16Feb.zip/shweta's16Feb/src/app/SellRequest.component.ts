import { Component } from '@angular/core';
import { SellRequest } from './SellRequest';
import { SellRequestService } from './SellRequestService';



@Component({
    selector: 'sellrequest',
    templateUrl: './SellRequest.component.html'
})

export class SellRequestcomponent {
    user: SellRequest = new SellRequest();
    response: string;

    keyPress(event: any) {
      const pattern = /[0-9\+\-\ ]/;
      let inputChar = String.fromCharCode(event.charCode);
      if (event.keyCode != 8 && !pattern.test(inputChar)) {
        event.preventDefault();
      }
    }

    constructor(private ms: SellRequestService){

    }
    
   

    store(){
      if(this.user.cropName!=null && this.user.cropType!=null  && this.user.fertilizerType!=null  && this.user.priceperquintal!=null && this.user.quantity!=null && this.user.soilpHCertificate!=null  ){
        let url = "http://localhost:8181/farmerCrop/add"
        this.ms.sendToServer(url,this.user).subscribe(data => {
            this.response = data['status'];
    });
}
    }
}