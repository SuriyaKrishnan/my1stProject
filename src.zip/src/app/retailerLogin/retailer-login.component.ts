import {OnInit} from '@angular/core';
import { Component } from "@angular/core";

@Component({
    selector : 'retailer-login',
    templateUrl: './retailer-login.component.html',
    //styleUrls:['./flights-list.component.css'],o
   
})


export class RetailerLoginComponent  {
    //flight:flights[]; o
    //source :string;o
    //destination:string;o
  
    constructor(){

    }
   

    
}