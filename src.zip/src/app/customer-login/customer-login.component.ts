import {OnInit} from '@angular/core';
import { Component } from "@angular/core";

@Component({
    selector : 'customer-login',
    templateUrl: './customer-login.component.html',
    //styleUrls:['./flights-list.component.css'],o
   
})


export class CustomerLoginComponent  {
    //flight:flights[]; o
    //source :string;o
    //destination:string;o
  
    constructor(){

    }
   
}