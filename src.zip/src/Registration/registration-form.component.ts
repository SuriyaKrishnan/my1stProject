
import { Component } from '@angular/core';


@Component({
// tslint:disable-next-line: component-selector
    selector : 'registration',
    templateUrl: './registration-form.component.html',
})


export class RegistrationComponent{

    constructor() {
    }
   
}
