

export class registration{
    constructor(public firstName?: string,
                public lastName?: string,
                public contact?: BigInteger,
                public address?: string,
                public email?: string,
                public password?: string)


               {

     }
}
