import {OnInit} from '@angular/core';
import { Component } from "@angular/core";

@Component({
    selector : 'login',
    templateUrl: './login-module.component.html',
   
})


export class LoginComponent  {
    
    constructor(){

    }
   
}