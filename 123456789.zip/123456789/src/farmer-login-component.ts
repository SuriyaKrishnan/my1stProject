import { FarmerLogin } from './farmer-login';
import { Component } from '@angular/core';
import { FarmerLoginService } from './farmer-login-service';
import { ActivatedRoute, Router } from '@angular/router'
@Component({
selector :'farmerlogin',
templateUrl:'./farmer-login-component.html',
//styleUrls: ['../css/mdb.min.css', '../css/bootstrap.min.css']
})

export class FarmerLoginComponent{
    farmerlogin: FarmerLogin = new FarmerLogin();
    response: string;
    email:string;
    password:string;
    request: string;
    router: any;
    constructor(private ms: FarmerLoginService){

    }
 add(mform){
        this.ms.sendToServer(this.email,this.password).subscribe(
            data => {
                this.request=data.toString();
                if(!+this.request){
                    alert("Login failed");
                    this.email="";
                    this.password="";
                }
                else{
                   this.router.navigate(["/farmerDashboard"]);
                    
                }

              
            }
        );
    }
   
    
    

   

}