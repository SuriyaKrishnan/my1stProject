import { Component } from '@angular/core';


@Component({
    selector: 'adminDashboard',
    templateUrl: './adminDashboard.component.html',
    styleUrls: ['./adminDashboard.component.css']

    
})

export class AdminDashboard{
    constructor(){

    }
    
}