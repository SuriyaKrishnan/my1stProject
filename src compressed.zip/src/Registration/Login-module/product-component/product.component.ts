import { Component } from '@angular/core';


@Component({
  selector: 'product',
  templateUrl: './product.component.html',
  
})
export class ProductComponent {
  title = 'ShoppingApp';
}
