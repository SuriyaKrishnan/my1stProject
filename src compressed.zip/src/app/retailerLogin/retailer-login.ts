export class Retailer{
    constructor(public email?: string,
                public password?:string,
                public otp?:string)
               {

     }
}
