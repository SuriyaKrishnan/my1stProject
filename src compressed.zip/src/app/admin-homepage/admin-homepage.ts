export class AdminHomepage{
    constructor(public id?: number,
        public name?:string,
       

    )
               {

     }
}
