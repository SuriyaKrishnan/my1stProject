import { Component } from '@angular/core';

import { Farmer } from 'src/app/Farmer';

import { FarmerService } from './FarmerService';
import { Router } from '@angular/router';

@Component({
selector :'add-farmer',
templateUrl:'./farmer-component.html',
//styleUrls: ['../css/mdb.min.css', '../css/bootstrap.min.css']
})

export class FarmerComponent{
    farmer: Farmer = new Farmer();
    response: string;
    confirmpass:String;
    array={ password:"" , msg: ""};
    constructor(private ms: FarmerService ,private router:Router){

    }

    keyPress(event: any) {
        const pattern = /[0-9\+\-\ ]/;
        let inputChar = String.fromCharCode(event.charCode);
        if (event.keyCode != 8 && !pattern.test(inputChar)) {
          event.preventDefault();
        }
      }

     
   add(mform){
    let confirm=true;

    if(this.farmer.confirmpassword != this.farmer.password){
        confirm=false;
        this.array['password'] = "Password does not match";
    }
   if(confirm){
    
        this.ms.sendToServer(this.farmer).subscribe(
            data => {
               
                this.response= data.toString();
            var check=this.response;
    
            if(check == "true"){
                alert("Thank You for Registering");
                this.router.navigate(['./login']);
            }
            }
        );
    } 

   

}
}