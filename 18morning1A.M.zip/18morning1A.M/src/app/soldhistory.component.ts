
import { Component} from "@angular/core";
@Component({
    selector: 'sold-history',
    templateUrl:  './soldhistory.component.html',
    styles: []
    })

export class SoldHistorycomponent

{   
    title: string ="List of Sold Products";
    history: any[] =[
        
    ] 
}
    
   

