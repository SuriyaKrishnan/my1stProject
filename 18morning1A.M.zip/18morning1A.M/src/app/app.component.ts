import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  template:`
  
  <div style="background-color:grey;" >
  <h1 style="text-align:center">
     {{title}}!
  </h1>
  </div>

    <home></home>
    
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'TradeCrops.com';
}


// <add-bidder></add-bidder>
// <login></login>
// <add-farmer></add-farmer>
// <farmerlogin></farmerlogin>
// <bidder-dashboard></bidder-dashboard>
// <admin-login></admin-login>