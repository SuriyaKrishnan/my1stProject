import {OnInit, Component} from '@angular/core';

@Component({
    selector : 'homebody',
    templateUrl: './homebody.component.html',
   // styleUrls:['./flights-list.component.css'],
})

export class HomepageBody{
   
     constructor(){ }
}