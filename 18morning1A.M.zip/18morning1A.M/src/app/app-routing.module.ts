import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { FarmerComponent } from 'src/app/FarmerComponent';
import { FarmerDashboard } from './farmerDashboard.component';
import { FarmerLoginComponent } from './farmer-login-component';
import { BidderLoginComponent } from './bidder-login-component';
import { BidderComponent } from './bidder-component';
import { BidderDashboard } from './bidder-dashboard';
import { HomeComponent } from './home-component';
import { SellRequestcomponent } from './SellRequest.component';
import { BidderDashboardComponent } from './bidder-dashboard-component';
import { SoldHistorycomponent } from './soldhistory.component';
import { ConstantDashboard } from './ConstantDashboard';
import { AdminLoginComponent } from './adminLogin.component';
import { AdminDashboardComponent } from './admin-dashboard-component';
import { AboutUsComponent } from './aboutus.component';
import { ContactUsComponent } from './contactus.component';
import { HomepageBody } from './homebody.component';






const routes: Routes = [

    { path: 'home',component: HomepageBody},
    { path: '',component: HomepageBody},

    { path: 'farmerlogin', component: FarmerLoginComponent},
    { path: 'login', component: BidderLoginComponent},
    { path: 'add-bidder', component: BidderComponent},
    { path: 'add-farmer', component: FarmerComponent},
    { path: 'farmerDashboard', component: FarmerDashboard},
    { path: 'bidder-dashboard', component: BidderDashboardComponent},
    {path: 'sellrequest',component:SellRequestcomponent},
    {path:'sold-history',component:SoldHistorycomponent},
    {path:'constant-Dashboard',component:ConstantDashboard},
    {path:'admin-login',component:AdminLoginComponent},
    {path:'admin-dashboard',component:AdminDashboardComponent},
    {path:'aboutus',component:AboutUsComponent},
    {path:'contactus',component:ContactUsComponent}

 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routing = RouterModule.forRoot(routes);
