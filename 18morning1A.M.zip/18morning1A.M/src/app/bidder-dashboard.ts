import {Component} from '@angular/core'

export class BidderDashboard {
   
    
    constructor(
       public cropId? :number,
        public cropType?:string,
        public cropName?:string,
        public quantity?:number,
        public priceperquintal?:string,
        public currentBid?:string
       
    ){

    }
}
