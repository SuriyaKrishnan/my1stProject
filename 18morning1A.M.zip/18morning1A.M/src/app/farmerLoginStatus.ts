export class farmerLoginStatus {

    public message: string;
    public farmerId: number;
    public fullName: string;
   

}