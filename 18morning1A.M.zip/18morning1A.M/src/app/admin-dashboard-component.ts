
import { Component } from '@angular/core';

@Component({
selector :'admin-dashboard',
templateUrl:'./admin-dashboard.html',
//styleUrls: ['../css/mdb.min.css', '../css/bootstrap.min.css']
})

export class AdminDashboardComponent{
    
  
    constructor(){

    }
}