import { BidderLogin } from './bidder-login';
import { Component } from '@angular/core';
import { BidderLoginService } from './bidder-login-service';
import { ActivatedRoute, Router } from '@angular/router'
import { LoginStatus } from './loginstatus';
@Component({
selector :'login',
templateUrl:'./bidder-login-component.html',
//styleUrls: ['../css/mdb.min.css', '../css/bootstrap.min.css']
})

export class BidderLoginComponent{
    login: BidderLogin = new BidderLogin();
    response: LoginStatus;
  
    constructor(private ms: BidderLoginService ,private router:Router){

    }
   add(mform){
        this.ms.sendToServer(this.login)
      
        .subscribe(data => { 
            this.response= data;
            if(this.response.message == "success"){
                sessionStorage.setItem("fullName", this.response.fullName);
                sessionStorage.setItem("bidderId", ""+this.response.bidderId);
                this.router.navigate(['./bidder-dashboard']);
            }
            else{
                this.login.email="";
               this.login.password="";
                this.router.navigate(['./login']);
                alert("Please check ur email id and password");
                
            }
        }
        );
    }
    
    

   

}